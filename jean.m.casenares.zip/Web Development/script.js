 
 /*Carousel*/
 var slideIndex,slide,dots;
 function slideContainer(){
     slideIndex=0;
     slide= document.getElementsByClassName("holder");
     slide[slideIndex].style.opacity=1;
 
 }
 slideContainer();
 
 function plusSlides(n){
     MoveSlide(slideIndex+n);
 }
 
 function MoveSlide(n){
     var i,current,next;
     var MoveSlideAnimClass={
         forCurrent : "",
         forNext:""
 
     }
     if(n>slideIndex){
         if(n>MoveSlideAnimClass.length){n=0;}
         MoveSlideAnimClass.forCurrent="MoveLeftCurrentSlide";
         MoveSlideAnimClass.forNext="MoveLeftNextSlide";
     }
     else if(n<MoveSlide)
     {
 
     }
     if(n!=slideIndex){
         next=slide[n];
         current=slide[slideIndex];
         for(i-0; i<slide.length; i++)
         {
             
             slide[i].style.opacity=0;
         }
         current.classList.add(MoveSlideAnimClass.forNext);
         next.classList.add(MoveSlideAnimClass.forNext);
     }
 }
 
 /*Modal*/
 const modalTrigger = document.querySelector(".add-btn");
 const modal = document.querySelectorAll(".modal");
 const modalClose = document.querySelectorAll(".close-btn");

 modalTrigger.addEventListener("click", event => {
     modal.style.display ="flex"; });


